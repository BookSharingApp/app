package com.example.jasmeetsingh.readapp;

/**
 * Created by Jasmeet Singh on 16-03-2018.
 */



public class PersonalDetails {
    // fields
    private String email_id;
    private String password;
    private String name;
    private double ph_no;
    private String address;
    // constructors
    public PersonalDetails() {
        //System.out.println("\tUsername and password cannot be blank! \tTry again.");
    }
    public PersonalDetails(String id, String pass) {
        this.email_id = id;
        this.password = pass;
    }
    // properties
    public void setID(String id) {
        this.email_id= id;
    }
    public String getID() {
        return this.email_id;
    }

    public void setPass(String pass) {
        this.password = pass;
    }

    public String getPass() {
        return this.password;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return this.name;
    }

    public void set_phone(double ph_no) {
        this.ph_no = ph_no;
    }
    public double get_phone() {
        return this.ph_no;
    }

    public void set_add(String add) {
        this.address = add;
    }
    public String get_add() {
        return this.address;
    }

}