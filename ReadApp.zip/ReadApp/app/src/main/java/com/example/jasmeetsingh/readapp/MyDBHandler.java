package com.example.jasmeetsingh.readapp;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jasmeet Singh on 16-03-2018.
 */

public class MyDBHandler extends SQLiteOpenHelper {
    //information of database
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "booksDB.db";
    public static final String TABLE_BOOK = " books";
    public static final String  BOOK_BOOK_ID = " bookid";
    public static final String BOOK_NAME = " bookname";
    public static final String BOOK_AUTHOR = " author";
    public static final String BOOK_PUBLISHER = " publisher";
    public static final String BOOK_OWNER = " owner";
    public static final String BOOK_TYPE = " type";

    public static final String Table_Borrower = " borrower";
    public static final String Borrower_id = " borrower_id";
    public static final String Lenders_id = " lenders_id";
    public static final String Borrower_Book_id = " book_id";
    public static final String Date_of_return = " date_of_return";
    public static final String Date_of_borrow = " date_of_borrow";

    public static final String TABLE_PDETAILS = "PersonalDetails";
    public static final String COLUMN_PD_EMAILID = "email_id";
    public static final String COLUMN_PD_NAME = "name";
    public static final String COLUMN_PD_PASSWORD = "password";
    public static final String COLUMN_PD_PHONE_NO = "ph_no";
    public static final String COLUMN_PD_ADDRESS = "address";

    //initialize the database
    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE" + TABLE_BOOK + "(" + BOOK_BOOK_ID +
                "INTEGER PRIMARYKEY," + BOOK_NAME + "TEXT" + BOOK_AUTHOR + "TEXT" + BOOK_PUBLISHER + "TEXT" +
                BOOK_OWNER + "TEXT" + BOOK_TYPE + "TEXT)";
        db.execSQL(CREATE_TABLE);
        String CREATE_TABLE_PDETAILS = "CREATE TABLE "
                + TABLE_PDETAILS + "(" + COLUMN_PD_EMAILID + " TEXT PRIMARY KEY," + COLUMN_PD_PASSWORD
                + " TEXT," + COLUMN_PD_NAME + " TEXT," + COLUMN_PD_PHONE_NO
                + " DOUBLE,"  + COLUMN_PD_ADDRESS + " TEXT," + ")";
        db.execSQL(CREATE_TABLE_PDETAILS);
        String CREATE_TABLE_Borrower = "CREATE TABLE "
                + Table_Borrower + "(" + Borrower_id + " TEXT," + Lenders_id
                + " TEXT," + Borrower_Book_id + " INT, PRIMARY KEY" + Date_of_return
                + " DATE,"  + Date_of_borrow + " DATE," + ")";
        db.execSQL(CREATE_TABLE_Borrower);
    }

    public void onUpgrade(SQLiteDatabase db, int i, int i1) {}

    public String book_load_handler() {
        String result = "";
        String query = "Select*FROM" + TABLE_BOOK;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            int result_0 = cursor.getInt(0);
            String result_1 = cursor.getString(1);
            String result_2 = cursor.getString(2);
            String result_3 = cursor.getString(3);
            String result_4 = cursor.getString(4);
            String result_5 = cursor.getString(5);
            result += String.valueOf(result_0) + " " + result_1 + result_2 + result_3 + result_4 +
                    result_5 + System.getProperty("line.separator");
        }
        cursor.close();
        db.close();
        return result;
    }

    public void book_add_handler(books book) {
        ContentValues values = new ContentValues();
        values.put(BOOK_BOOK_ID, book.getID());
        values.put(BOOK_NAME, book.getbookName());
        values.put(BOOK_AUTHOR, book.getauthor());
        values.put(BOOK_PUBLISHER, book.getpublisher());
        values.put(BOOK_OWNER, book.getowner());
        values.put(BOOK_TYPE, book.gettype());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_BOOK, null, values);
        db.close();
    }

    public books book_find_handler(String bookname) {
        String query = "Select * FROM " + TABLE_BOOK + "WHERE" + BOOK_NAME + " = " + "'" + bookname + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        books book = new books();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            book.setID(Integer.parseInt(cursor.getString(0)));
            book.setbookName(cursor.getString(1));
            book.setauthor(cursor.getString(2));
            book.setpublisher(cursor.getString(3));
            book.setowner(cursor.getString(5));
            book.settype(cursor.getString(6));
            cursor.close();
        } else {
            book = null;
        }
        db.close();
        return book;
    }

    public boolean book_delete_handler(int ID) {
        boolean result = false;
        String query = "Select*FROM" + TABLE_BOOK + "WHERE" + BOOK_BOOK_ID + "= '" + String.valueOf(ID) + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        books book = new books();
        if (cursor.moveToFirst()) {
            book.setID(Integer.parseInt(cursor.getString(0)));
            db.delete(TABLE_BOOK, BOOK_BOOK_ID + "=?",
                    new String[] {
                String.valueOf(book.getID())
            });
            cursor.close();
            result = true;
        }
        db.close();
        return result;
    }

    public boolean book_update_handler(int ID, String name, String author, String publisher,
                                       String owner, String type) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(BOOK_BOOK_ID, ID);
        args.put(BOOK_NAME, name);
        args.put(BOOK_AUTHOR, author);
        args.put(BOOK_PUBLISHER, publisher);
        args.put(BOOK_OWNER, owner);
        args.put(BOOK_TYPE, type);
        return db.update(TABLE_BOOK, args, BOOK_BOOK_ID + "=" + ID, null) > 0;
    }

    //from here borrower's function

    @Override

    public String borrower_load_handler() {
        String result = "";
        String query = "Select*FROM" + Table_Borrower;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String result_0 = cursor.getString(0);
            String result_1 = cursor.getString(1);
            int result_2 = cursor.getInt(2);
            Date result_3 = (Date.valueOf(cursor.getString(3)));
            Date result_4 = (Date.valueOf(cursor.getString(4)));
            result += String.valueOf(result_0) + " " + result_1 + result_2 + result_3 + result_4 + System.getProperty("line.separator");
        }
        cursor.close();
        db.close();
        return result;
    }

    public void borrower_add_handler(borrower borrow) {
        ContentValues values = new ContentValues();
        values.put(Borrower_id, borrow.get_borrower_id());
        values.put(Lenders_id, borrow.get_lenders_id());
        values.put(Borrower_Book_id, borrow.get_book_id());
        values.put(Date_of_return, String.valueOf(borrow.get_doreturn()));
        values.put(Date_of_borrow, String.valueOf(borrow.get_doborrow()));
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(Table_Borrower, null, values);
        db.close();
    }

    public borrower borrower_find_handler(int bookid) {
        String query = "Select * FROM " + Table_Borrower + "WHERE" + Borrower_Book_id + " = " + String.valueOf(bookid) ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        borrower borrowed = new borrower();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            borrowed.set_borrower_id(cursor.getString(0));
            borrowed.set_lenders_id(cursor.getString(1));
            borrowed.set_book_id(Integer.parseInt(cursor.getString(2)));
            borrowed.set_doreturn(Date.valueOf(cursor.getString(3)));
            borrowed.set_doborrow(Date.valueOf(cursor.getString(4)));
            cursor.close();
        } else {
            borrowed = null;
        }
        db.close();
        return borrowed;
    }

    public boolean borrower_delete_handler(int ID) {
        boolean result = false;
        String query = "Select*FROM" + Table_Borrower + "WHERE" + Borrower_Book_id + "= '" + String.valueOf(ID) + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        borrower book = new borrower();
        if (cursor.moveToFirst()) {
            book.set_book_id(Integer.parseInt(cursor.getString(0)));
            db.delete(Table_Borrower, Borrower_Book_id + "=?",
                    new String[] {
                            String.valueOf(book.get_book_id())
                    });
            cursor.close();
            result = true;
        }
        db.close();
        return result;
    }

    public boolean borrower_update_handler(String borrow_id, String lend_id, int ID,
                                           Date ofreturn, Date lent) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(Borrower_id, borrow_id);
        args.put(Lenders_id, lend_id);
        args.put(Borrower_Book_id, ID);
        args.put(Date_of_return, String.valueOf(ofreturn));
        args.put(Date_of_borrow, String.valueOf(lent));
        return db.update(TABLE_BOOK, args, BOOK_BOOK_ID + "=" + ID, null) > 0;
    }

    //from here P_Details function
    public List<PersonalDetails> load_PDetails() {
        List<PersonalDetails> PDetail = new ArrayList<PersonalDetails>();
        String selectQuery = "SELECT  * FROM " + TABLE_PDETAILS;

        Log.e("INVALID QUERY");

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                PersonalDetails pd = new PersonalDetails();
                pd.setID(c.getString((c.getColumnIndex(COLUMN_PD_EMAILID))));
                pd.setPass(c.getString((c.getColumnIndex(COLUMN_PD_PASSWORD))));
                pd.setName(c.getString((c.getColumnIndex(COLUMN_PD_NAME))));
                pd.set_phone((c.getInt(c.getColumnIndex(COLUMN_PD_PHONE_NO))));
                pd.set_add(c.getString(c.getColumnIndex(COLUMN_PD_ADDRESS)));

                // adding to todo list
                PDetail.add(pd);
            } while (c.moveToNext());
        }

        return PDetail;
    }
    public void add_PDetails(TABLE_PDETAILS Details) {}
    public TABLE_PDETAILS find_PDetail(String string_val) {}
    public boolean delete_PDetails(String email) {}
    public boolean update_PDetails(String email, String pass, String name, double ph_no, String address) {}
}